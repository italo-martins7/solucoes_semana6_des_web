USE ex_pais;

INSERT INTO paises (nome, populacao, area) VALUES ('Albânia', 2876591, 28748.00), ('Bósnia e Herzegovina', 3861912, 51197.00),
('Suécia', 10171524, 449964.00), ('Chipre', 1141166, 9521.00),('Croácia', 4154200, 56594.00);

select * from paises;

